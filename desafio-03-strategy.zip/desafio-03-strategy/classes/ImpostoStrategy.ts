export default abstract class ImpostoStrategy {
  abstract calcularImposto(valor: number): number;
}
